from django.apps import AppConfig


class VmiAppConfig(AppConfig):
    name = 'vmi_app'
